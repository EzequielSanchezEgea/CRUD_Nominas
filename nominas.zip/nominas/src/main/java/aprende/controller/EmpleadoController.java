package aprende.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aprende.dao.EmpleadoDAO;
import aprende.model.Empleado;
import aprende.model.Nomina;

/**
 * Servlet implementation class EmpleadoController
 * <p>
 * Este servlet gestiona las operaciones CRUD para empleados. Permite listar,
 * buscar, modificar, guardar y eliminar empleados, así como buscar sus
 * salarios.
 * </p>
 * 
 * <p>
 * Las acciones principales están determinadas por el parámetro "opcion"
 * recibido en la solicitud.
 * </p>
 * 
 * <ul>
 * <li>listar: Muestra la lista de empleados.</li>
 * <li>salarios: Muestra el formulario para buscar salarios.</li>
 * <li>obtenerSalarios: Busca el salario de un empleado basado en su DNI.</li>
 * <li>modificar: Muestra el formulario para modificar un empleado.</li>
 * <li>guardar: Guarda un nuevo empleado.</li>
 * <li>editar: Edita la información de un empleado.</li>
 * <li>eliminar: Elimina un empleado de la base de datos.</li>
 * </ul>
 * 
 * @see HttpServlet
 */
@WebServlet("/empleado")
public class EmpleadoController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public EmpleadoController() {
        super();
    }

    /**
     * Maneja las solicitudes GET.
     * 
     * Dependiendo de la opción recibida, realiza diferentes acciones como listar
     * empleados, buscar salarios, o mostrar formularios de modificación.
     * 
     * @param request  La solicitud HTTP recibida.
     * @param response La respuesta HTTP enviada.
     * @throws ServletException Si ocurre un error con el servlet.
     * @throws IOException      Si ocurre un error de entrada/salida.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String opcion = request.getParameter("opcion");

        if ("listar".equals(opcion)) {
            // Listar todos los empleados
            EmpleadoDAO empleadosDAO = new EmpleadoDAO();
            List<Empleado> lista = new ArrayList<>();
            try {
                lista = empleadosDAO.obtenerTodosLosEmpleados();
                request.setAttribute("lista", lista);
                request.getRequestDispatcher("/views/listar.jsp").forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Error al obtener la lista de empleados: " + e.getMessage());
                request.getRequestDispatcher("/views/error.jsp").forward(request, response);
            }
            System.out.println("Usted ha presionado la opción listar");

        } else if ("salarios".equals(opcion)) {
            // Mostrar formulario para buscar salarios
            request.getRequestDispatcher("/views/salario.jsp").forward(request, response);
            System.out.println("Usted ha presionado la opción buscar salarios");

        } else if ("obtenerSalarios".equals(opcion)) {
            // Obtener salario por DNI
            EmpleadoDAO empleadosDAO = new EmpleadoDAO();
            Double obtenerSalario = null;
            String dni = request.getParameter("dni");
            try {
                obtenerSalario = empleadosDAO.obtenerNominaPorDni(dni);
                request.setAttribute("obtenerSalarios", obtenerSalario);
                request.getRequestDispatcher("/views/salario.jsp").forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Error al obtener el salario: " + e.getMessage());
                request.getRequestDispatcher("/views/error.jsp").forward(request, response);
            }

        } else if ("mostrar".equals(opcion)) {
            // Mostrar empleados
            request.getRequestDispatcher("/views/mostrar.jsp").forward(request, response);
            System.out.println("Usted ha presionado la opción mostrar");

        } else if ("modificar".equals(opcion)) {
            // Mostrar formulario de modificación
            request.getRequestDispatcher("/views/modificar.jsp").forward(request, response);
            System.out.println("Usted ha presionado la opción modificar");
        }
    }

    /**
     * Maneja las solicitudes POST.
     * 
     * Dependiendo de la opción recibida, realiza acciones como buscar salarios,
     * guardar, editar o eliminar empleados, o buscar empleados por atributo.
     * 
     * @param request  La solicitud HTTP recibida.
     * @param response La respuesta HTTP enviada.
     * @throws ServletException Si ocurre un error con el servlet.
     * @throws IOException      Si ocurre un error de entrada/salida.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String opcion = request.getParameter("opcion");

        if ("obtenerSalarios".equals(opcion)) {
            // Obtener salario por DNI desde un formulario
            EmpleadoDAO empleadosDAO = new EmpleadoDAO();
            String dni = request.getParameter("dni");
            String mensaje = " ";

            Double sueldo = null;

            try {
                sueldo = empleadosDAO.obtenerNominaPorDni(dni);
                if (sueldo == null) {
                    mensaje = "No se pudo encontrar un empleado con el DNI proporcionado.";
                }
            } catch (SQLException e) {
                e.printStackTrace();
                mensaje = "Error al consultar el salario. Intente con otro DNI.";
            }

            request.setAttribute("dni", dni);
            request.setAttribute("sueldo", sueldo);
            request.setAttribute("mensaje", mensaje);
            request.getRequestDispatcher("/views/salario.jsp").forward(request, response);

        } else if ("buscarPorAtributo".equals(opcion)) {
            // Buscar empleados por un atributo específico
            EmpleadoDAO empleadosDAO = new EmpleadoDAO();
            List<Empleado> listaEmpleados = new ArrayList<>();
            String atributo = request.getParameter("atributo");
            String valor = request.getParameter("valor");

            try {
                listaEmpleados = empleadosDAO.buscarEmpleadosPorAtributo(atributo, valor);
                for (Empleado empleado : listaEmpleados) {
                    int sueldo = Nomina.sueldo(empleado);
                    empleado.setSueldoTotal(sueldo);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Error al buscar empleados: " + e.getMessage());
                request.getRequestDispatcher("/views/error.jsp").forward(request, response);
                return;
            }

            request.setAttribute("listaEmpleados", listaEmpleados);
            request.getRequestDispatcher("/views/mostrar.jsp").forward(request, response);

        } else if ("guardar".equals(opcion)) {
            System.out.println("Intentando guardar---");
            // Guardar un nuevo empleado
            EmpleadoDAO empleadoDAO = new EmpleadoDAO();
            Empleado empleado = new Empleado();
            empleado.setDni(request.getParameter("dni"));
            empleado.setNombre(request.getParameter("nombre"));
            empleado.setSexo(request.getParameter("sexo").charAt(0));
            empleado.setCategoria(Integer.parseInt(request.getParameter("categoria")));
            empleado.setAnyos(Integer.parseInt(request.getParameter("anyos")));

            // Listar todos los empleados
            List<Empleado> lista = new ArrayList<>();

            try {
                // Intentar guardar el nuevo empleado
                if (empleadoDAO.guardarEmpleado(empleado)) {
                    request.setAttribute("mensajeExito", "Empleado guardado exitosamente.");
                } else {
                    request.setAttribute("mensajeError", "Error al guardar el empleado.");
                }

                // Ahora obtener la lista actualizada de empleados
                lista = empleadoDAO.obtenerTodosLosEmpleados();
                request.setAttribute("lista", lista);
                
                // Redirigir a listar.jsp
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/listar.jsp");
                requestDispatcher.forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("mensajeError", "Error al guardar el empleado: " + e.getMessage());
                
                try {
                    lista = empleadoDAO.obtenerTodosLosEmpleados();
                    request.setAttribute("lista", lista);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    request.setAttribute("error", "Error al obtener la lista de empleados: " + ex.getMessage());
                }
                
                // Redirigir a listar.jsp para mostrar el error y la lista
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/listar.jsp");
                requestDispatcher.forward(request, response);
            }

        } else if ("editar".equals(opcion)) {
            // Recoger el DNI original desde el formulario
            String dniOriginal = request.getParameter("dniOriginal");
            
            // Editar información de un empleado
            Empleado empleado = new Empleado();
            EmpleadoDAO empleadoDAO = new EmpleadoDAO();

            // Recoger los nuevos datos del formulario
            empleado.setDni(request.getParameter("dni"));
            empleado.setNombre(request.getParameter("nombre"));
            empleado.setSexo(request.getParameter("sexo").charAt(0));
            empleado.setCategoria(Integer.parseInt(request.getParameter("categoria")));
            empleado.setAnyos(Integer.parseInt(request.getParameter("anyos")));

            // Recalcular el sueldo basado en la nueva categoría y años
            int sueldoActualizado = Nomina.sueldo(empleado);
            empleado.setSueldoTotal(sueldoActualizado); // Establecer el nuevo sueldo

            String mensaje;
            try {
                // Llamar al método editar del DAO, pasando el empleado y el dniOriginal
                mensaje = empleadoDAO.editar(empleado, dniOriginal); // Actualizar en la base de datos
                request.setAttribute("mensajeExito", mensaje);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("mensajeError", "Error al modificar el empleado. Inténtalo de nuevo.");
            }

            // Reenviar los valores actualizados a modificar.jsp
            request.setAttribute("empleado", empleado);
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/modificar.jsp");
            requestDispatcher.forward(request, response);
        }else if ("eliminar".equals(opcion)) {
            System.out.println("Intentando eliminar---");
            String dni = request.getParameter("dni"); // Obtener el DNI del empleado a eliminar
            EmpleadoDAO empleadoDAO = new EmpleadoDAO();
            
            try {
                // Llamar al método para eliminar el empleado
                boolean eliminado = empleadoDAO.eliminar(dni);
                
                if (eliminado) {
                    request.setAttribute("mensajeExito", "Empleado eliminado exitosamente.");
                } else {
                    request.setAttribute("mensajeError", "Error al eliminar el empleado. Verifica que el empleado exista.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("mensajeError", "Error al eliminar el empleado: " + e.getMessage());
            }
            
            // Listar todos los empleados después de la eliminación
            List<Empleado> lista = new ArrayList<>();
            try {
                lista = empleadoDAO.obtenerTodosLosEmpleados();
                request.setAttribute("lista", lista);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Error al obtener la lista de empleados: " + e.getMessage());
            }
            
            // Redirigir a la vista de listar
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/listar.jsp");
            requestDispatcher.forward(request, response);
        }

    }
}
